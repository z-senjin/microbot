package net.runelite.client.plugins.microbot.mntn.MntnSlayer.data;

public enum GearStyle {
    MELEE,
    RANGE,
    MAGE
}
