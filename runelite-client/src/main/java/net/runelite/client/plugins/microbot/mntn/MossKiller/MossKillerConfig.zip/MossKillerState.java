package net.runelite.client.plugins.microbot.mntn.MossKiller;

public enum MossKillerState {
    TELEPORT,
    WALK_TO_BANK,
    BANK,
    WALK_TO_MOSS_GIANTS,
    WALK_TO_BOSS,
    FIGHT_BOSS,
    FIGHT_MOSS_GIANTS,
    EXIT_SCRIPT
}
