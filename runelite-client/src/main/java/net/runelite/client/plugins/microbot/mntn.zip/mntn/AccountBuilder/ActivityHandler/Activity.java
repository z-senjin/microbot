package net.runelite.client.plugins.microbot.mntn.AccountBuilder.ActivityHandler;

public enum Activity{
    SKILL,
    QUEST,
    MINIGAME,
    TUTORIAL_ISLAND,
    MONEY_MAKER,
    CHILL
}
